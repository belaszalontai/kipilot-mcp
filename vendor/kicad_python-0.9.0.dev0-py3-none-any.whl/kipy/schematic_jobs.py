# Copyright The KiCad Developers
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the “Software”), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import annotations

from collections.abc import Sequence

from kipy.board_jobs import JobResult
from kipy.proto.schematic import schematic_jobs_pb2
from kipy.wrapper import Wrapper

__all__ = (
    "BOMField",
    "BOMFieldSettings",
    "BOMFormatSettings",
    "JobResult",
    "PlotSettings",
)


class PlotSettings(Wrapper):
    """Shared settings for schematic plotting jobs.

    When plotting all sheets, set ``plot_all=True`` and leave ``plot_pages``
    empty unless you know the exact sheet-instance paths to filter.
    """

    def __init__(
        self,
        proto: schematic_jobs_pb2.SchematicPlotSettings | None = None,
        proto_ref: schematic_jobs_pb2.SchematicPlotSettings | None = None,
    ):
        self._proto = (
            proto_ref if proto_ref is not None else schematic_jobs_pb2.SchematicPlotSettings()
        )
        if proto is not None:
            self._proto.CopyFrom(proto)

    @property
    def drawing_sheet(self) -> str:
        return self._proto.drawing_sheet

    @drawing_sheet.setter
    def drawing_sheet(self, value: str):
        self._proto.drawing_sheet = value

    @property
    def default_font(self) -> str:
        return self._proto.default_font

    @default_font.setter
    def default_font(self, value: str):
        self._proto.default_font = value

    @property
    def variant(self) -> str:
        return self._proto.variant

    @variant.setter
    def variant(self, value: str):
        self._proto.variant = value

    @property
    def plot_all(self) -> bool:
        return self._proto.plot_all

    @plot_all.setter
    def plot_all(self, value: bool):
        self._proto.plot_all = value

    @property
    def plot_drawing_sheet(self) -> bool:
        return self._proto.plot_drawing_sheet

    @plot_drawing_sheet.setter
    def plot_drawing_sheet(self, value: bool):
        self._proto.plot_drawing_sheet = value

    @property
    def plot_pages(self) -> list[str]:
        return list(self._proto.plot_pages)

    @plot_pages.setter
    def plot_pages(self, value: Sequence[str]):
        del self._proto.plot_pages[:]
        self._proto.plot_pages.extend(value)

    @property
    def show_hop_over(self) -> bool:
        return self._proto.show_hop_over

    @show_hop_over.setter
    def show_hop_over(self, value: bool):
        self._proto.show_hop_over = value

    @property
    def black_and_white(self) -> bool:
        return self._proto.black_and_white

    @black_and_white.setter
    def black_and_white(self, value: bool):
        self._proto.black_and_white = value

    @property
    def page_size(self) -> schematic_jobs_pb2.SchematicJobPageSize.ValueType:
        return self._proto.page_size

    @page_size.setter
    def page_size(self, value: schematic_jobs_pb2.SchematicJobPageSize.ValueType):
        self._proto.page_size = value

    @property
    def use_background_color(self) -> bool:
        return self._proto.use_background_color

    @use_background_color.setter
    def use_background_color(self, value: bool):
        self._proto.use_background_color = value

    @property
    def min_pen_width(self) -> int:
        return self._proto.min_pen_width

    @min_pen_width.setter
    def min_pen_width(self, value: int):
        self._proto.min_pen_width = value

    @property
    def theme(self) -> str:
        return self._proto.theme

    @theme.setter
    def theme(self, value: str):
        self._proto.theme = value


class BOMFormatSettings(Wrapper):
    """Formatting settings for schematic BOM export jobs."""

    def __init__(
        self,
        proto: schematic_jobs_pb2.BOMFormatSettings | None = None,
        proto_ref: schematic_jobs_pb2.BOMFormatSettings | None = None,
    ):
        self._proto = (
            proto_ref if proto_ref is not None else schematic_jobs_pb2.BOMFormatSettings()
        )
        if proto is not None:
            self._proto.CopyFrom(proto)

    @property
    def preset_name(self) -> str:
        return self._proto.preset_name

    @preset_name.setter
    def preset_name(self, value: str):
        self._proto.preset_name = value

    @property
    def field_delimiter(self) -> str:
        return self._proto.field_delimiter

    @field_delimiter.setter
    def field_delimiter(self, value: str):
        self._proto.field_delimiter = value

    @property
    def string_delimiter(self) -> str:
        return self._proto.string_delimiter

    @string_delimiter.setter
    def string_delimiter(self, value: str):
        self._proto.string_delimiter = value

    @property
    def ref_delimiter(self) -> str:
        return self._proto.ref_delimiter

    @ref_delimiter.setter
    def ref_delimiter(self, value: str):
        self._proto.ref_delimiter = value

    @property
    def ref_range_delimiter(self) -> str:
        return self._proto.ref_range_delimiter

    @ref_range_delimiter.setter
    def ref_range_delimiter(self, value: str):
        self._proto.ref_range_delimiter = value

    @property
    def keep_tabs(self) -> bool:
        return self._proto.keep_tabs

    @keep_tabs.setter
    def keep_tabs(self, value: bool):
        self._proto.keep_tabs = value

    @property
    def keep_line_breaks(self) -> bool:
        return self._proto.keep_line_breaks

    @keep_line_breaks.setter
    def keep_line_breaks(self, value: bool):
        self._proto.keep_line_breaks = value


class BOMField(Wrapper):
    """One exported field column definition for schematic BOM jobs."""

    def __init__(
        self,
        proto: schematic_jobs_pb2.BOMField | None = None,
        proto_ref: schematic_jobs_pb2.BOMField | None = None,
    ):
        self._proto = proto_ref if proto_ref is not None else schematic_jobs_pb2.BOMField()
        if proto is not None:
            self._proto.CopyFrom(proto)

    @property
    def name(self) -> str:
        return self._proto.name

    @name.setter
    def name(self, value: str):
        self._proto.name = value

    @property
    def label(self) -> str:
        return self._proto.label

    @label.setter
    def label(self, value: str):
        self._proto.label = value

    @property
    def group_by(self) -> bool:
        return self._proto.group_by

    @group_by.setter
    def group_by(self, value: bool):
        self._proto.group_by = value


class BOMFieldSettings(Wrapper):
    """Field-selection settings for schematic BOM export jobs."""

    def __init__(
        self,
        proto: schematic_jobs_pb2.BOMFieldSettings | None = None,
        proto_ref: schematic_jobs_pb2.BOMFieldSettings | None = None,
    ):
        self._proto = proto_ref if proto_ref is not None else schematic_jobs_pb2.BOMFieldSettings()
        if proto is not None:
            self._proto.CopyFrom(proto)

    @property
    def preset_name(self) -> str:
        return self._proto.preset_name

    @preset_name.setter
    def preset_name(self, value: str):
        self._proto.preset_name = value

    @property
    def fields(self) -> list[BOMField]:
        return [BOMField(proto_ref=field) for field in self._proto.fields]

    @fields.setter
    def fields(self, value: Sequence[BOMField]):
        del self._proto.fields[:]
        self._proto.fields.extend(field.proto for field in value)

    @property
    def sort_field(self) -> str:
        return self._proto.sort_field

    @sort_field.setter
    def sort_field(self, value: str):
        self._proto.sort_field = value

    @property
    def sort_direction(self) -> schematic_jobs_pb2.BOMSortDirection.ValueType:
        return self._proto.sort_direction

    @sort_direction.setter
    def sort_direction(self, value: schematic_jobs_pb2.BOMSortDirection.ValueType):
        self._proto.sort_direction = value

    @property
    def filter(self) -> str:
        return self._proto.filter

    @filter.setter
    def filter(self, value: str):
        self._proto.filter = value
